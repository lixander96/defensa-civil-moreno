export interface JwtPayload {
    id: number,
    username: string,
    password: string
}