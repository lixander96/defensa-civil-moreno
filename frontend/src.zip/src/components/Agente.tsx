import { AgenteMovil } from './AgenteMovil';

export function Agente() {
  return <AgenteMovil />;
}